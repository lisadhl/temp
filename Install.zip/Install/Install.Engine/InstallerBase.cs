﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Threading;

using static System.Console;

namespace A.Install.Engine
{
    public abstract class InstallerBase : IDisposable
    {
        public void Install()
        {
            string[] args = Environment.GetCommandLineArgs();

            if (args != null)
            {
                WriteLine("Command args: {0}", string.Join(" ", args));
            }

            try
            {
                WriteLine("Start install...");
                DoInstall();
            }
            catch (Exception ex)
            {
                Error.WriteLine("Install failed {0}", ex);

                WriteLine();
                WriteLine("Press any key to exit...");
                ReadKey(intercept: true);
            }
        }

        private void DoInstall()
        {
            Type type = GetType();
            InstallInfo info = new InstallInfo(type);

            string target = Path.Combine(info.RootDirectory, info.Name);
            WriteLine("Prepare deploy \"{0}\" to \"{1}\"", info.Name, target);

            using (Stream stream = info.Read())
            {
                if (Directory.Exists(target))
                {
                    WriteLine("Folder \"{0}\" exists. Prepare to delete...", target);
                    Directory.Delete(target, recursive: true);
                    WriteLine("Folder \"{0}\" was deleted", target);
                }

                WriteLine("Prepare extract \"{0}.zip\" to \"{1}\"", info.Name, target);

                ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Read);
                archive.ExtractToDirectory(info.RootDirectory);

                WriteLine("\"{0}.zip\" was extracted to \"{1}\"", info.Name, target);
            }

            if (info.EnableAutoStartup)
            {
                WriteLine("Try to startup \"{0}\"", info.StartupPath);
                info.Startup();
                WriteLine("Startup \"{0}\" succeeded", info.StartupPath);
            }

            WriteLine("Install succeeded at \"{0}\"", target);
            Thread.Sleep(3000);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }

    internal sealed class InstallInfo
    {
        private readonly Type _installerType;

        public InstallInfo(Type installerType)
        {
            _installerType = installerType;

            InstallAttribute installAttr = (InstallAttribute)Attribute.GetCustomAttribute(installerType, typeof(InstallAttribute))
                                           ?? throw new InvalidOperationException($"Type {installerType} should flag attribute {nameof(InstallAttribute)}");

            RootDirectory = installAttr.RootDirectory;
            Name = installAttr.Name;
            AutoStartup = installAttr.AutoStartup;
        }

        public string RootDirectory { get; private set; }

        public string Name { get; private set; }

        public string AutoStartup { get; }

        public Stream Read()
        {
            Stream stream = _installerType.Assembly.GetManifestResourceStream(_installerType, $"{Name}.zip")
                            ?? throw new InvalidOperationException($"Deploy {Name} not found");

            return stream;
        }

        public bool EnableAutoStartup => !string.IsNullOrEmpty(AutoStartup);

        public string StartupPath => Path.Combine(RootDirectory, Name, AutoStartup);

        public void Startup()
        {
            if (!EnableAutoStartup)
            {
                return;
            }

            ProcessStartInfo startInfo = new ProcessStartInfo()
            {
                FileName = StartupPath,
            };

            Process.Start(startInfo);
        }
    }
}
