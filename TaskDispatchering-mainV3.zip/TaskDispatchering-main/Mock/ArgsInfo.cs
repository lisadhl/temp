﻿namespace Mock
{
    internal readonly record struct ArgsInfo(string Name, string Host, int Steps, bool ThrowError)
    {
    }
}
