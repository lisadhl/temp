﻿// 接收 JSON 参数
Console.WriteLine("Accept arguments:");
Console.WriteLine(args[0]);
