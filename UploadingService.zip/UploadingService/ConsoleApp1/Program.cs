﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.IO;
using System.IO.Compression;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {            
            MultipartFormDataContent multipartFormDataContent = new MultipartFormDataContent();
            StreamContent content = new StreamContent(ZipMyLogs());
            multipartFormDataContent.Add(content,"test2",Guid.NewGuid().ToString()+".zip");
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://localhost:44391/upload.ashx");
            request.Content = multipartFormDataContent;
            HttpClient client = new HttpClient();
            HttpResponseMessage respons = client.SendAsync(request).Result;

            Console.WriteLine(respons);

            Console.WriteLine(respons.StatusCode);
        }

        private static Stream ZipMyLogs()
        {
            string zippingDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MyLogs");
            string tempFile = Path.Combine(GetTempDir(), Guid.NewGuid().ToString());
            
            ZipFile.CreateFromDirectory(zippingDir, tempFile);

            return File.OpenRead(tempFile);
        }

        private static string GetTempDir()
        {
            string tempDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "temp");

            if (!Directory.Exists(tempDir))
            {
                Directory.CreateDirectory(tempDir);
            }

            return tempDir;
        }
    }
}
